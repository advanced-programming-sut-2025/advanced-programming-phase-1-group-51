package Models;

public class Quest {

    public Quest() {
    }
}

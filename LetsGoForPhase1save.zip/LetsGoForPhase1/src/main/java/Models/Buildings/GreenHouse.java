package Models.Buildings;

import Models.Maps.Cells;

import java.util.ArrayList;

public class GreenHouse extends Building {

    public GreenHouse() {
    }

    public GreenHouse(ArrayList<Cells> buildingCells) {
        super(buildingCells);
    }
}

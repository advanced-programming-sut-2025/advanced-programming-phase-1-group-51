package Models.Buildings;

import Models.Maps.Cells;

import java.util.ArrayList;

public class House extends  Building {

    public House() {
    }

    public House(ArrayList<Cells> buildingCells) {
        super(buildingCells);

    }
}

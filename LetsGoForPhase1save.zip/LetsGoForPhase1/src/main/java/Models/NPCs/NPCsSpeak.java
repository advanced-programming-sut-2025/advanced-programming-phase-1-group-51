package Models.NPCs;

import java.util.ArrayList;

public class NPCsSpeak {


    private ArrayList<String>NPCMessage;


}


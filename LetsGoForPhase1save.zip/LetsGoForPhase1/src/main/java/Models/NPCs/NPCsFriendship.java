package Models.NPCs;

public class NPCsFriendship {




}

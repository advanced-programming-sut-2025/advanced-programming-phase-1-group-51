package Models.ObjectsShownOnMap;

public class StoreCell extends ObjectOnMap{
}

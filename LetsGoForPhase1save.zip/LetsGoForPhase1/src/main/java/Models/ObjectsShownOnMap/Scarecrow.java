package Models.ObjectsShownOnMap;

public class Scarecrow extends ObjectOnMap{

    public Scarecrow() {
        super(false, "sacreCrow", "red");
    }
}

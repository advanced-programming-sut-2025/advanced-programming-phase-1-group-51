package Models.ObjectsShownOnMap;

public class HouseCell extends ObjectOnMap{

    public HouseCell() {
        super(false, "building", "gray");
    }
}

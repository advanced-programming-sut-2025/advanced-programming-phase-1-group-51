package Views.GameMenus.Others;

import Models.App;
import Models.Game;
import Views.PlayMenu;

import java.util.Scanner;
import java.util.regex.Matcher;

public class HouseMenu implements PlayMenu {
    @Override
    public void check(Scanner scanner) {
        String input = App.scanner.nextLine();
        Matcher matcher;

    }
}

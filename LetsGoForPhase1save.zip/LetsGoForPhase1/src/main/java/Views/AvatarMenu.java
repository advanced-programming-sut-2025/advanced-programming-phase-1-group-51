package Views;

import Controllers.MenuControllers.AvatarMenuController;

import java.util.Scanner;

public class AvatarMenu implements PlayMenu{

    private final AvatarMenuController controller = new AvatarMenuController();
    @Override
    public void check(Scanner scanner){

    }
}

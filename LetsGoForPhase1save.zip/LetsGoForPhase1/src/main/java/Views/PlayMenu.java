package Views;

import java.util.Scanner;
import java.util.regex.Matcher;

public interface PlayMenu {
    public abstract void check(Scanner scanner);
}

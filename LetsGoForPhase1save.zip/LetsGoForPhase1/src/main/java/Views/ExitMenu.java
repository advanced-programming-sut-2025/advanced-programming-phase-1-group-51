package Views;

import java.util.Scanner;

public class ExitMenu implements  PlayMenu{

    @Override
    public void check(Scanner scanner){

    }
}

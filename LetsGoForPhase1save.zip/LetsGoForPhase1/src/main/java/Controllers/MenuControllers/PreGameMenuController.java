package Controllers.MenuControllers;

import Controllers.BaseController;
import Controllers.Services.UserService;
import Models.*;
import Models.Enums.MenuCommands.Menu;
import Models.Maps.Cells;
import Models.Maps.Farm;
import Models.Maps.Map;

import java.util.ArrayList;

public class PreGameMenuController extends BaseController {
    public Result goToMain() {
        User user = App.getCurrentUser();
        Game game = user.getCurrentGame();
        App.setCurrentMenu(Menu.MainMenu);
        return new Result(true,  "you are now in main menu");
    }


    public Result showCurrentMenu(){
        User user = App.getCurrentUser();
        if (user == null) {
            return Result.failure("No user logged in");
        }

        Game game = user.getCurrentGame();
        if (game != null) {
            return saveGameState(game)
                    .combine(Result.success("PreGame Menu (game exists)"));
        }
        return Result.success("PreGame Menu (no active game)");
    }

    public Result newGame(String firstUsername, String secondUsername, String thirdUsername, String extraInvalid) {
        User currentUser = App.getCurrentUser();
        if (currentUser == null) {
            return Result.failure("No user logged in");
        }

        if (currentUser.getCurrentGame() != null) {
            return Result.failure("You are already in a game");
        }

        // Validate and collect all participating users
        ArrayList<User> participants = new ArrayList<>();
        participants.add(currentUser);

        // Add first username if provided
        if (firstUsername != null && !firstUsername.isEmpty()) {
            User user1 = validateAndAddUser(firstUsername);
            if (user1 == null) {
                return Result.failure(firstUsername + " doesn't exist or is in a game");
            }
            participants.add(user1);
        }

        // Add second username if provided
        if (secondUsername != null && !secondUsername.isEmpty()) {
            User user2 = validateAndAddUser(secondUsername);
            if (user2 == null) {
                return Result.failure(secondUsername + " doesn't exist or is in a game");
            }
            participants.add(user2);
        }

        // Add third username if provided
        if (thirdUsername != null && !thirdUsername.isEmpty()) {
            User user3 = validateAndAddUser(thirdUsername);
            if (user3 == null) {
                return Result.failure(thirdUsername + " doesn't exist or is in a game");
            }
            participants.add(user3);
        }

        Game newGame = new Game(new ArrayList<>(), null);

        // Initialize the map properly
        newGame.setMap(Map.makeMap());

        // Create players
        for (User user : participants) {
            Player player = new Player(user);
            // Initialize player's farm
            Farm farm = new Farm(participants.indexOf(user) + 1); // Farm numbers start at 1
            player.setFarm(farm);

            newGame.getPlayers().add(player);
            user.setCurrentGame(newGame);
        }

        // Set first player as current
        if (!newGame.getPlayers().isEmpty()) {
            newGame.setCurrentPlayer(newGame.getPlayers().get(0));
        }

        return saveGameState(newGame)
                .combine(Result.success("New game created successfully."));
    }

    private User validateAndAddUser(String username) {
        if (username == null || username.trim().isEmpty()) {
            return null;
        }

        // Refresh user list
        new UserService().loadAllUsers();

        // Find user (case insensitive)
        for (User user : User.getUsers()) {
            if (user.getUsername().equalsIgnoreCase(username.trim())) {
                if (user.getCurrentGame() != null) {
                    return null; // User is already in a game
                }
                return user;
            }
        }
        return null; // User not found
    }

    public Result gameMap(int mapNumber){
        User user = App.getCurrentUser();
        Game game = user.getCurrentGame();
        if (mapNumber != 1 && mapNumber != 2) {
            return  Result.failure( "Invalid map number");
        }

        return saveGameState(game)
                .combine(Result.success( "map number chose successfully"));
    }

    public Result loadGame() {
        User currentUser = App.getCurrentUser();
        Game game = currentUser.getCurrentGame();

        if (game == null) {
            return Result.failure("No saved game found.");
        }

        Player currentPlayer = game.findPlayerByUser(currentUser);
        if (currentPlayer == null) {
            return Result.failure("Error: Could not find your player in the game");
        }

        game.setCurrentPlayer(currentPlayer);

        // Set player position to their farmhouse
        Farm playerFarm = currentPlayer.getFarm();
        Cells farmHouse = playerFarm.findCellFarm(10, 10); // Or use getFarmHousePosition()
        if (farmHouse != null) {
            currentPlayer.setPosition(farmHouse.getPosition());
        }

        App.setCurrentMenu(Menu.GameMenu);

        return saveGameState(game)
                .combine(Result.success("Game loaded successfully. Welcome to the game!"));
    }


    private User findUserByUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            return null;
        }

        // First check the static list
        for (User user : User.getUsers()) {
            if (user.getUsername().equalsIgnoreCase(username.trim())) {
                return user;
            }
        }

        // If not found, try loading from service
        UserService userService = new UserService();
        userService.loadAllUsers(); // Refresh the user list

        // Check again after refresh
        for (User user : User.getUsers()) {
            if (user.getUsername().equalsIgnoreCase(username.trim())) {
                return user;
            }
        }

        return null;
    }
}

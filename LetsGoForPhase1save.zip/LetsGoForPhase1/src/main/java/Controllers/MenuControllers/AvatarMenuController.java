package Controllers.MenuControllers;

import Models.Result;

public class AvatarMenuController {


    public static Result showCurrentMenu(){
        return new Result(true, "Avatar Menu");
    }
}

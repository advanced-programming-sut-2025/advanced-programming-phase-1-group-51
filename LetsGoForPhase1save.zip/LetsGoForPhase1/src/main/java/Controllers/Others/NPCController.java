package Controllers.Others;

import Controllers.BaseController;
import Models.Result;

public class NPCController extends BaseController {

    public Result NPCMeet(String NPCName) {
        return null;
    }

    public Result NPCGift(String NPCName, String item) {
        return null;
    }

    public Result FriendShipNPCList() {
        return null;
    }

    public Result QuestList() {
        return null;
    }

    public Result QuestFinish(int index) {
        return null;
    }


}

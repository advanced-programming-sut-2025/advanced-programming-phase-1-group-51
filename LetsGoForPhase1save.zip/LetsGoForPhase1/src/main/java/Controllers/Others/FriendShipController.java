package Controllers.Others;

import Controllers.BaseController;
import Models.Result;

public class FriendShipController  extends BaseController {

    public Result FriendShip() {
        return null;
    }

    public Result Talk(String username, String message) {
        return null;
    }

    public Result TalkHistory(String username) {
        return null;
    }

    public Result Gift(String username, String item, int amount) {
        return null;
    }

    public Result GiftList() {
        return null;
    }

    public Result GiftRate(int giftNumber, int giftRate) {
        return null;
    }

    public Result GiftHistory(String username) {
        return null;
    }

    public Result Hug(String username) {
        return null;
    }

    public Result Flower(String username) {
        return null;
    }

    public Result AskMarriage(String username, String ring) {
        return null;
    }

    public Result Respond(String respond,String username){
        return null;
    }








}

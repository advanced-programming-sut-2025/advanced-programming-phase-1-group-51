package Controllers.Activity;

import Controllers.BaseController;
import Models.Result;

public class Trading extends BaseController {

    public Result TradeWithUser(String username, String type, String item, int amount) {
        return null;
    }
    public Result TradeList() {
        return null;
    }
    public Result TradeResponse(String response, int id) {
        return null;
    }
    public Result TradeHistory() {
        return null;
    }
}

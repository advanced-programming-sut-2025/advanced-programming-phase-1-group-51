package Controllers.Services;

import Models.Game;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;

public class GameStorageService {
    private static final String SAVE_DIRECTORY = "saved_games/";
    private final Gson gson;

    public GameStorageService() {
        this.gson = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
                .setExclusionStrategies(new ExclusionStrategy() {
                    @Override
                    public boolean shouldSkipField(FieldAttributes f) {
                        return f.getAnnotation(JsonIgnore.class) != null;
                    }

                    @Override
                    public boolean shouldSkipClass(Class<?> clazz) {
                        return false;
                    }
                })
                .setPrettyPrinting()
                .create();
    }

    // Save only game state
    public void saveGameState(Game game) throws IOException {
        ensureSaveDirectoryExists();
        String gameFilename = SAVE_DIRECTORY + "game_" + game.getPlayers().get(0).getUser().getUsername() + ".json";
        Files.writeString(Paths.get(gameFilename), gson.toJson(game));
    }

    // Load a specific game
    public Game loadGame(String username) throws IOException {
        File gameFile = new File(SAVE_DIRECTORY + "game_" + username + ".json");
        if (gameFile.exists()) {
            String json = Files.readString(gameFile.toPath());
            return gson.fromJson(json, Game.class);
        }
        return null;
    }

    private void ensureSaveDirectoryExists() throws IOException {
        Files.createDirectories(Paths.get(SAVE_DIRECTORY));
    }

}

import Views.GameView;

public class Main {
    public static void main(String[] args) {


        System.out.println("Enter your commands below:");
        (new GameView()).run();

    }
}